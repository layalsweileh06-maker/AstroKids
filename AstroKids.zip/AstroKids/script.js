const T = {
  en: {
    badge: "Junior Astronaut Mission Trainer",
    tagline: "Become a real astronaut and run a base in space!",
    loginTitle: "Let's fly to space! 🚀",
    nameLabel: "Your astronaut nickname",
    nameHint: "Use a nickname, not your real name.",
    ageLabel: "How old are you?",
    genderLabel: "Choose your astronaut",
    girl: "Girl",
    boy: "Boy",
    start: "🚀 Start training",
    errName: "Please type a nickname (2 letters or more).",
    errAge: "Please choose your age.",
    errGender: "Please choose your astronaut.",
    welcomeBoy: "Welcome, Commander {name}!",
    welcomeGirl: "Welcome, Commander {name}!",
    chooseWorld: "Where will you build your base?",
    moon: "The Moon",
    moonDesc: "Close to Earth: about 3 days away. The Sun shines for about 2 weeks, then it is night for 2 weeks!",
    mars: "Mars",
    marsDesc: "Far away: about 6 to 9 months of travel. Sunlight is weak and dust storms can cover the whole planet!",
    back: "← Back",
    dayWord: "Day",
    whatDo: "What will you do?",
    realBadge: "🛰️ Real NASA data",
    youChose: "You chose:",
    whyWord: "Why?",
    dailyNote: "Every day the base also uses some supplies.",
    nextDay: "Next day ➜",
    seeReport: "See mission report ➜",
    winTitle: "🎉 Mission Success!",
    failTitle: "💥 Mission Failed",
    winText: "Your crew is safe after 7 days on {world}! You are a real base commander!",
    failText: "{meter} ran out! Real mission controllers watch every system all the time.",
    lessons: "What you learned",
    dataNote: "The solar storm and the asteroid in this mission came from real NASA data (DONKI and NeoWs).",
    again: "🔄 Play again",
    newPlayer: "👩‍🚀 New astronaut",
    alertWord: "ALERT!",
    warning: "WARNING! Low"
  },
  ar: {
    badge: "مدرّب رواد الفضاء الصغار",
    tagline: "كن رائد فضاء حقيقي وأدر قاعدتك في الفضاء!",
    loginTitle: "هيا نطير إلى الفضاء! 🚀",
    nameLabel: "اسمك المستعار كرائد فضاء",
    nameHint: "استخدم اسماً مستعاراً وليس اسمك الحقيقي.",
    ageLabel: "كم عمرك؟",
    genderLabel: "اختر رائد الفضاء",
    girl: "بنت",
    boy: "ولد",
    start: "🚀 ابدأ التدريب",
    errName: "اكتب اسماً مستعاراً (حرفان أو أكثر).",
    errAge: "اختر عمرك.",
    errGender: "اختر رائد الفضاء.",
    welcomeBoy: "أهلاً بالقائد {name}!",
    welcomeGirl: "أهلاً بالقائدة {name}!",
    chooseWorld: "أين ستبني قاعدتك؟",
    moon: "القمر",
    moonDesc: "قريب من الأرض: حوالي 3 أيام فقط. الشمس تضيء حوالي أسبوعين، ثم يصير ليل لأسبوعين!",
    mars: "المريخ",
    marsDesc: "بعيد: رحلة من 6 إلى 9 أشهر تقريباً. ضوء الشمس ضعيف وعواصف الغبار قد تغطي الكوكب كله!",
    back: "رجوع →",
    dayWord: "اليوم",
    whatDo: "ماذا ستفعل؟",
    realBadge: "🛰️ بيانات حقيقية من ناسا",
    youChose: "اخترت:",
    whyWord: "لماذا؟",
    dailyNote: "كل يوم تستهلك القاعدة أيضاً بعض المؤن.",
    nextDay: "اليوم التالي ➜",
    seeReport: "شاهد تقرير المهمة ➜",
    winTitle: "🎉 نجحت المهمة!",
    failTitle: "💥 فشلت المهمة",
    winText: "طاقمك بأمان بعد 7 أيام على {world}! أنت قائد قاعدة حقيقي!",
    failText: "نفد {meter}! مراقبو المهمات الحقيقيون يراقبون كل نظام طوال الوقت.",
    lessons: "ماذا تعلمت",
    dataNote: "العاصفة الشمسية والكويكب في هذه المهمة جاءا من بيانات ناسا الحقيقية (DONKI وNeoWs).",
    again: "🔄 العب مرة أخرى",
    newPlayer: "👩‍🚀 رائد جديد",
    alertWord: "إنذار!",
    warning: "تحذير! منخفض"
  }
};

let lang = "en";
let player = { name: "", age: null, gender: null };
let currentWorld = "moon";

/* ---------- Mission data ---------- */
const KEYS = ["power", "oxygen", "water", "food", "shield"];
const ICON = { power: "⚡", oxygen: "💨", water: "💧", food: "🍎", shield: "☢️" };
const MN = {
  en: { power: "Power", oxygen: "Oxygen", water: "Water", food: "Food", shield: "Shield" },
  ar: { power: "الطاقة", oxygen: "الأكسجين", water: "المياه", food: "الغذاء", shield: "الحماية" }
};
const ORDER = {
  moon: ["night", "oxygen", "storm", "leak", "asteroid", "ice", "harvest"],
  mars: ["dust", "oxygen", "storm", "leak", "asteroid", "ice", "harvest"]
};
const DROP = {
  moon: { power: 6, oxygen: 6, water: 5, food: 6, shield: 2 },
  mars: { power: 7, oxygen: 7, water: 6, food: 7, shield: 3 }
};
const START = 80;

function B(en, ar) { return { en: en, ar: ar }; }
function L(o) { return o[lang]; }

const ND = (typeof NASA_DATA !== "undefined") ? NASA_DATA : null;

const SC = {
  night: {
    icon: "🌑",
    title: B("The long lunar night begins", "بدأ الليل القمري الطويل"),
    story: B("The Sun has set! On the Moon, night lasts about 14 Earth days, so your solar panels make no power.",
             "غابت الشمس! الليل على القمر يدوم حوالي 14 يوماً أرضياً، فلا تنتج الألواح الشمسية أي كهرباء."),
    fact: B("Real fact: on the Moon, daytime and night each last about 2 weeks.",
            "حقيقة: على القمر يدوم النهار والليل حوالي أسبوعين لكل منهما."),
    choices: [
      { label: B("Turn off extra lights to save power", "أطفئ الأضواء الإضافية لتوفير الطاقة"),
        fx: { power: 12, food: -12 },
        why: B("You saved power, but plants need light to grow, so food dropped.", "وفّرت الطاقة، لكن النباتات تحتاج الضوء لتنمو فانخفض الغذاء.") },
      { label: B("Use the batteries as usual", "استخدم البطاريات كالمعتاد"),
        fx: { power: -18 },
        why: B("Batteries drain fast during the long night.", "تنفد البطاريات بسرعة في الليل الطويل.") },
      { label: B("Start the backup power plant", "شغّل محطة الطاقة الاحتياطية"),
        fx: { power: 18, water: -12 },
        why: B("Backup power works at night, but it needs cooling water.", "الطاقة الاحتياطية تعمل ليلاً، لكنها تحتاج ماء للتبريد.") }
    ]
  },
  dust: {
    icon: "🌪️",
    alert: true,
    title: B("A giant dust storm!", "عاصفة غبار عملاقة!"),
    story: B("Dust covers the sky and your solar panels. On Mars, dust storms can last for weeks and sometimes cover the whole planet.",
             "يغطي الغبار السماء والألواح الشمسية. عواصف الغبار على المريخ قد تستمر أسابيع وأحياناً تغطي الكوكب كله."),
    fact: B("Real fact: Mars gets less than half the sunlight that Earth gets.",
            "حقيقة: يصل إلى المريخ أقل من نصف ضوء الشمس الذي يصل إلى الأرض."),
    choices: [
      { label: B("Go outside and clean the panels", "اخرج ونظّف الألواح"),
        fx: { power: 15, shield: -10 },
        why: B("Clean panels make power again, but Mars has very thin air, so going outside means more radiation.", "الألواح النظيفة تنتج الكهرباء من جديد، لكن هواء المريخ رقيق جداً فالخروج يعني إشعاعاً أكثر.") },
      { label: B("Wait inside until it passes", "انتظر في الداخل حتى تمر العاصفة"),
        fx: { power: -20 },
        why: B("Safe, but dusty panels give very little power.", "آمن، لكن الألواح المغبّرة تعطي كهرباء قليلة جداً.") },
      { label: B("Save power: keep only life support on", "وفّر الطاقة: شغّل أنظمة الحياة فقط"),
        fx: { power: -5, food: -10 },
        why: B("Smart saving, but the plants lost their lights.", "توفير ذكي، لكن النباتات فقدت أضواءها.") }
    ]
  },
  oxygen: {
    icon: "💨",
    title: B("Time to make oxygen", "حان وقت صنع الأكسجين"),
    story: B("Every astronaut breathes oxygen all day. Your oxygen maker is running low, and it uses a lot of electricity.",
             "يتنفس كل رائد فضاء الأكسجين طوال اليوم. جهاز الأكسجين عندك يقل إنتاجه، ويستهلك كهرباء كثيرة."),
    fact: B("Real fact: NASA's MOXIE experiment made oxygen from the carbon dioxide in Mars air.",
            "حقيقة: جهاز MOXIE التابع لناسا صنع الأكسجين من ثاني أكسيد الكربون في هواء المريخ."),
    choices: [
      { label: B("Run the oxygen maker all day", "شغّل جهاز الأكسجين طوال اليوم"),
        fx: { oxygen: 25, power: -18 },
        why: B("Plenty of air, but it costs a lot of power.", "هواء وفير، لكنه يكلّف الكثير من الطاقة.") },
      { label: B("Run it a little", "شغّله قليلاً"),
        fx: { oxygen: 10, power: -6 },
        why: B("A balanced choice: some air, little power.", "خيار متوازن: بعض الهواء وقليل من الطاقة.") },
      { label: B("Do not run it today", "لا تشغّله اليوم"),
        fx: { oxygen: -15, power: 8 },
        why: B("You saved power, but the air is getting thin.", "وفّرت الطاقة، لكن الهواء بدأ يقل.") }
    ]
  },
  storm: {
    icon: "☀️",
    alert: true,
    real: true,
    scale: true,
    title: B("Solar storm alert!", "إنذار عاصفة شمسية!"),
    story: function (d) {
      return B("Mission Control spotted a real solar eruption (a CME) on " + d.date + ", moving at " + d.speed + " km/s. Radiation is on its way!",
               "رصد مركز التحكم انفجاراً شمسياً حقيقياً بتاريخ " + d.date + " بسرعة " + d.speed + " كم/ث. الإشعاع في الطريق إلينا!");
    },
    fact: B("Real fact: Earth's magnetic field protects us, but the Moon and Mars have no such shield.",
            "حقيقة: المجال المغناطيسي للأرض يحمينا، أما القمر والمريخ فليس لديهما هذا الدرع."),
    choices: [
      { label: B("Hide in the shelter", "اختبئ في الملجأ"),
        fx: { shield: -4, food: -8 },
        why: B("The shelter keeps everyone safe, but work stopped for a day.", "الملجأ يحمي الجميع، لكن العمل توقف يوماً كاملاً.") },
      { label: B("Keep working outside", "تابع العمل في الخارج"),
        fx: { shield: -28, food: 8 },
        why: B("Strong radiation can harm astronauts. Not worth the risk!", "الإشعاع القوي قد يؤذي رواد الفضاء. المخاطرة ليست مجدية!") },
      { label: B("Fill the water wall", "املأ جدار الماء"),
        fx: { shield: 12, water: -18 },
        why: B("Water is a great radiation shield, but it uses up your water.", "الماء درع ممتاز ضد الإشعاع، لكنه يستهلك مياهك.") }
    ]
  },
  leak: {
    icon: "🔧",
    alert: true,
    title: B("Oh no, a leak!", "يا للهول، هناك تسريب!"),
    story: B("A pipe is leaking air and water. The crew must decide fast!",
             "أنبوب يسرّب الهواء والماء. على الطاقم أن يقرر بسرعة!"),
    fact: B("Real fact: on the space station, astronauts recycle almost all of their water, even from sweat and breath.",
            "حقيقة: في محطة الفضاء يعيد الرواد تدوير معظم مياههم، حتى من العرق والتنفس."),
    choices: [
      { label: B("Fix the leak right away", "أصلح التسريب فوراً"),
        fx: { water: 8, power: -10 },
        why: B("Fixing fast saves water, but the tools need power.", "الإصلاح السريع يوفر الماء، لكن الأدوات تحتاج طاقة.") },
      { label: B("Ignore it for now", "تجاهله الآن"),
        fx: { water: -20, oxygen: -12 },
        why: B("Small leaks get big! Both air and water leaked out.", "التسريبات الصغيرة تكبر! خسرنا الهواء والماء معاً.") },
      { label: B("Close the broken room", "أغلق الغرفة المتضررة"),
        fx: { oxygen: -5, water: -6, food: -6 },
        why: B("You stopped the leak, but lost a room and some supplies.", "أوقفت التسريب، لكنك خسرت غرفة وبعض المؤن.") }
    ]
  },
  asteroid: {
    icon: "☄️",
    alert: true,
    real: true,
    title: B("Asteroid alert!", "إنذار كويكب!"),
    story: function (d) {
      return B("NASA is tracking asteroid " + d.name + " (about " + d.diameterM + " meters wide). On " + d.date + " it will pass about " + d.missLunar + " times the Moon's distance from Earth.",
               "تتابع ناسا الكويكب " + d.name + " (عرضه حوالي " + d.diameterM + " متراً). في " + d.date + " سيمر على بعد " + d.missLunar + " ضعف المسافة بين الأرض والقمر.");
    },
    fact: B("Real fact: NASA tracks asteroids near Earth every day to know where they will go.",
            "حقيقة: تتابع ناسا الكويكبات القريبة من الأرض يومياً لتعرف إلى أين تتجه."),
    choices: [
      { label: B("Panic! Everyone to the shelter", "ذعر! الجميع إلى الملجأ"),
        fx: { food: -8, power: -6 },
        why: B("Scientists calculated its path and it passes safely. Panic only wastes time.", "حسب العلماء مساره وسيمر بسلام. الذعر يضيّع الوقت فقط.") },
      { label: B("Keep working and watch the radar", "تابع العمل وراقب الرادار"),
        fx: { food: 8, power: 4 },
        why: B("Great choice! Experts track asteroids for years, so you can stay calm and watch the data.", "اختيار رائع! يتابع الخبراء الكويكبات لسنوات، فيمكنك الهدوء ومراقبة البيانات.") },
      { label: B("Take photos for scientists", "التقط صوراً للعلماء"),
        fx: { power: -8, food: 4 },
        why: B("Cool idea! Photos help scientists, but cameras use power.", "فكرة رائعة! الصور تساعد العلماء، لكن الكاميرات تستهلك الطاقة.") }
    ]
  },
  ice: {
    icon: "🧊",
    title: B("The rover found ice!", "المركبة وجدت جليداً!"),
    story: B("Your rover found frozen water hidden in the ground. Ice can become drinking water, and even oxygen!",
             "عثرت مركبتك على ماء متجمد مخبأ تحت الأرض. يمكن تحويل الجليد إلى ماء للشرب وحتى إلى أكسجين!"),
    fact: B("Real fact: there is water ice in dark craters at the Moon's south pole, and under the ground on Mars.",
            "حقيقة: يوجد جليد مائي في فوهات مظلمة عند القطب الجنوبي للقمر وتحت سطح المريخ."),
    choices: [
      { label: B("Mine a lot of ice", "استخرج كمية كبيرة من الجليد"),
        fx: { water: 25, power: -14 },
        why: B("Lots of water, but digging uses a lot of power.", "ماء كثير، لكن الحفر يستهلك طاقة كبيرة.") },
      { label: B("Mine a little ice", "استخرج القليل"),
        fx: { water: 12, power: -5 },
        why: B("A balanced choice: some water, little power.", "خيار متوازن: بعض الماء وقليل من الطاقة.") },
      { label: B("Turn the ice into oxygen", "حوّل الجليد إلى أكسجين"),
        fx: { oxygen: 18, power: -12 },
        why: B("Electricity can split water into oxygen and hydrogen.", "الكهرباء تفصل الماء إلى أكسجين وهيدروجين.") }
    ]
  },
  harvest: {
    icon: "🥬",
    title: B("Garden day!", "يوم الحديقة!"),
    story: B("Your space garden is ready. Plants give food and fresh air, but they need water and light.",
             "حديقتك الفضائية جاهزة. النباتات تعطي الغذاء والهواء النقي، لكنها تحتاج ماء وضوءاً."),
    fact: B("Real fact: astronauts have grown lettuce and radishes on the space station.",
            "حقيقة: زرع رواد الفضاء الخس والفجل في محطة الفضاء."),
    choices: [
      { label: B("Water the plants a lot", "اسقِ النباتات كثيراً"),
        fx: { food: 25, water: -16 },
        why: B("Big harvest, but it used a lot of water.", "حصاد كبير، لكنه استهلك ماءً كثيراً.") },
      { label: B("Water them a little", "اسقِها قليلاً"),
        fx: { food: 12, water: -6 },
        why: B("A balanced choice: some food, little water.", "خيار متوازن: بعض الغذاء وقليل من الماء.") },
      { label: B("Pick everything and eat now", "اقطف كل شيء وكل الآن"),
        fx: { food: 18, oxygen: -6 },
        why: B("A big meal today, but fewer plants means less fresh air.", "وجبة كبيرة اليوم، لكن النباتات الأقل تعني هواءً نقياً أقل.") }
    ]
  }
};

/* ---------- Real NASA data picks ---------- */
function pickData(id) {
  if (id === "storm") {
    if (ND && ND.cme && ND.cme.recent && ND.cme.recent.length) {
      return ND.cme.recent[Math.floor(Math.random() * ND.cme.recent.length)];
    }
    return { date: "2026-11-10", speed: 500 };
  }
  if (id === "asteroid") {
    if (ND && ND.asteroids && ND.asteroids.length) {
      return ND.asteroids[Math.floor(Math.random() * ND.asteroids.length)];
    }
    return { name: "2018 NE1", date: "2026-11-19", diameterM: 90, missLunar: 16.6 };
  }
  return null;
}
function stormK(d) {
  return d.speed > 600 ? 1.5 : d.speed > 350 ? 1 : 0.6;
}

/* ---------- Astronaut drawings (girl = pink, boy = blue) ---------- */
function avatar(g) {
  let girl = g === "girl";
  let suit = girl ? "#ff4fa3" : "#2f7bff";
  let dark = girl ? "#c42a78" : "#1b55c4";
  let hair = girl ? "#6b3410" : "#3b2412";

  let extras = "";
  if (girl) {
    extras =
      '<circle cx="19" cy="52" r="12" fill="' + hair + '"/>' +
      '<circle cx="101" cy="52" r="12" fill="' + hair + '"/>' +
      '<path d="M12 40 L28 46 L12 52 Z M108 40 L92 46 L108 52 Z" fill="#ff4fa3"/>' +
      '<path d="M60 8 L44 -2 L44 18 Z M60 8 L76 -2 L76 18 Z" fill="#ff4fa3" transform="translate(0,6)"/>' +
      '<circle cx="60" cy="14" r="5" fill="#ffd1e8"/>';
  } else {
    extras =
      '<rect x="57" y="-4" width="6" height="16" rx="3" fill="#cfd6f5"/>' +
      '<circle cx="60" cy="-4" r="5" fill="#ffd166"/>';
  }

  let lashes = girl
    ? '<path d="M49 44 L46 41 M53 43 L52 39 M71 44 L74 41 M67 43 L68 39" stroke="#222" stroke-width="2" stroke-linecap="round"/>'
    : "";

  let hairTop = girl
    ? '<path d="M41 45 Q41 24 60 24 Q79 24 79 45 Q70 31 60 33 Q50 31 41 45 Z" fill="' + hair + '"/>'
    : '<path d="M42 40 Q44 25 60 25 Q76 25 78 40 Q68 32 60 34 Q52 32 42 40 Z" fill="' + hair + '"/>';

  let chest = girl
    ? '<path d="M60 96 C48 86 52 78 60 84 C68 78 72 86 60 96 Z" fill="#fff"/>'
    : '<circle cx="52" cy="88" r="4" fill="#ffd166"/><circle cx="68" cy="88" r="4" fill="#3ddc84"/>';

  return '<svg viewBox="0 -12 120 162" width="140" height="175" style="max-width:100%" xmlns="http://www.w3.org/2000/svg">' +
    '<rect x="26" y="64" width="68" height="50" rx="12" fill="#9aa3c7"/>' +
    '<rect x="40" y="108" width="17" height="30" rx="7" fill="' + suit + '"/>' +
    '<rect x="63" y="108" width="17" height="30" rx="7" fill="' + suit + '"/>' +
    '<rect x="37" y="132" width="23" height="13" rx="6" fill="#fff"/>' +
    '<rect x="60" y="132" width="23" height="13" rx="6" fill="#fff"/>' +
    '<rect x="14" y="68" width="20" height="40" rx="10" fill="' + suit + '"/>' +
    '<rect x="86" y="68" width="20" height="40" rx="10" fill="' + suit + '"/>' +
    '<circle cx="24" cy="110" r="9" fill="#fff"/><circle cx="96" cy="110" r="9" fill="#fff"/>' +
    '<rect x="34" y="62" width="52" height="52" rx="16" fill="' + suit + '"/>' +
    '<rect x="46" y="76" width="28" height="26" rx="6" fill="' + dark + '"/>' + chest +
    extras +
    '<rect x="44" y="70" width="32" height="9" rx="4" fill="#e6e9f8"/>' +
    '<circle cx="60" cy="42" r="35" fill="#fff" stroke="#cfd6f5" stroke-width="3"/>' +
    '<ellipse cx="60" cy="44" rx="27" ry="24" fill="#16224f"/>' +
    '<circle cx="60" cy="47" r="19" fill="#ffd7b0"/>' + hairTop +
    '<circle cx="53" cy="48" r="3" fill="#222"/><circle cx="67" cy="48" r="3" fill="#222"/>' + lashes +
    '<circle cx="47" cy="55" r="4" fill="#ff9aa8" opacity=".7"/><circle cx="73" cy="55" r="4" fill="#ff9aa8" opacity=".7"/>' +
    '<path d="M52 55 Q60 63 68 55" stroke="#a33" stroke-width="2.5" fill="none" stroke-linecap="round"/>' +
    '<path d="M38 30 Q46 20 58 20" stroke="#fff" stroke-width="4" fill="none" opacity=".45" stroke-linecap="round"/>' +
    '</svg>';
}

function saveData(key, value) {
  try { localStorage.setItem(key, value); } catch (e) {}
}
function loadData(key) {
  try { return localStorage.getItem(key); } catch (e) { return null; }
}

/* ---------- Language and screens ---------- */
function setLang(l) {
  lang = l;
  saveData("ak_lang", l);
  document.documentElement.lang = l;
  document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
  document.getElementById("btn-en").classList.toggle("on", l === "en");
  document.getElementById("btn-ar").classList.toggle("on", l === "ar");
  refreshTexts();
  rerender();
}

function refreshTexts() {
  document.querySelectorAll("[data-i18n]").forEach(function (el) {
    el.textContent = T[lang][el.dataset.i18n];
  });
  document.getElementById("nickname").placeholder = lang === "ar" ? "مثال: نجم الفضاء" : "Example: StarKid";

  document.getElementById("astroAvatar").innerHTML = avatar(player.gender || "boy");

  let key = player.gender === "girl" ? "welcomeGirl" : "welcomeBoy";
  document.getElementById("welcome").textContent = T[lang][key].replace("{name}", player.name);
}

function showScreen(id) {
  document.querySelectorAll(".screen").forEach(function (s) {
    s.classList.remove("active");
  });
  document.getElementById(id).classList.add("active");
  refreshTexts();
}

function pickAge(a) {
  player.age = a;
  document.querySelectorAll(".age").forEach(function (b) {
    b.classList.toggle("sel", Number(b.dataset.age) === a);
  });
}

function pickGender(g) {
  player.gender = g;
  document.getElementById("g-girl").classList.toggle("sel", g === "girl");
  document.getElementById("g-boy").classList.toggle("sel", g === "boy");
}

function startTraining() {
  let name = document.getElementById("nickname").value.trim();
  let err = document.getElementById("error");

  if (name.length < 2) { err.textContent = T[lang].errName; return; }
  if (!player.age) { err.textContent = T[lang].errAge; return; }
  if (!player.gender) { err.textContent = T[lang].errGender; return; }

  err.textContent = "";
  player.name = name;
  saveData("ak_player", JSON.stringify(player));
  showScreen("worldScreen");
}

/* ---------- The mission ---------- */
let state = { world: "moon", day: 0, meters: {}, log: [], phase: "", cur: null, last: null, failKey: null };

function pickWorld(w) {
  currentWorld = w;
  state = { world: w, day: 0, meters: {}, log: [], phase: "choose", cur: null, last: null, failKey: null };
  KEYS.forEach(function (k) { state.meters[k] = START; });
  showScreen("gameScreen");
  renderDay();
  maybeAlarm();
}

function beep() {
  try {
    let AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!window.akAudio) window.akAudio = new AC();
    let ac = window.akAudio;
    [0, 0.25].forEach(function (t) {
      let o = ac.createOscillator();
      let g = ac.createGain();
      o.type = "square";
      o.frequency.value = 880;
      g.gain.value = 0.05;
      o.connect(g);
      g.connect(ac.destination);
      o.start(ac.currentTime + t);
      o.stop(ac.currentTime + t + 0.15);
    });
  } catch (e) {}
}

function maybeAlarm() {
  if (state.cur && SC[state.cur.id].alert) beep();
}

function rerender() {
  if (state.phase === "choose") renderDay();
  else if (state.phase === "result") renderResult();
  else if (state.phase === "end") renderEnd();
}

function renderTop() {
  let total = ORDER[state.world].length;
  let dots = "";
  for (let i = 0; i < total; i++) {
    dots += '<span class="dot' + (i < state.day ? " done" : i === state.day ? " now" : "") + '"></span>';
  }
  document.getElementById("topline").innerHTML =
    '<div class="dayBox">' + T[lang].dayWord + " " + (state.day + 1) + " / " + total + "</div>" +
    '<div class="dots">' + dots + "</div>";

  let m = "";
  KEYS.forEach(function (k) {
    let v = Math.max(0, Math.round(state.meters[k]));
    let col = v < 30 ? "#ff4d4d" : v < 55 ? "#ffd166" : "#3ddc84";
    m += '<div class="chip' + (v < 30 ? " low" : "") + '"><div class="top"><span>' + ICON[k] + " " + MN[lang][k] + "</span><span>" + v + '%</span></div>' +
         '<div class="bar2"><i style="width:' + v + "%;background:" + col + '"></i></div></div>';
  });
  document.getElementById("meters").innerHTML = m;

  let low = KEYS.filter(function (k) { return state.meters[k] < 30; });
  let al = document.getElementById("alarm");
  al.className = low.length ? "alarm on" : "alarm";
  al.innerHTML = low.length
    ? "🚨 " + T[lang].warning + ": " + low.map(function (k) { return MN[lang][k]; }).join(" · ")
    : "";

  document.getElementById("scene").className = state.world;
  document.getElementById("sceneAstro").innerHTML = avatar(player.gender || "boy");
}

function renderDay() {
  state.phase = "choose";
  let id = ORDER[state.world][state.day];
  let s = SC[id];
  if (!state.cur || state.cur.id !== id) state.cur = { id: id, data: pickData(id) };
  let story = typeof s.story === "function" ? s.story(state.cur.data) : s.story;

  let html = '<div class="sc">' + (s.alert ? '<div class="alertbar">🚨 ' + T[lang].alertWord + " 🚨</div>" : "") + '<div class="ic">' + s.icon + "</div><h2>" + L(s.title) + "</h2>";
  if (s.real) html += '<div class="center"><span class="real">' + T[lang].realBadge + "</span></div>";
  html += '<p class="story">' + L(story) + "</p>";
  html += '<div class="factbox">💡 ' + L(s.fact) + "</div>";
  html += "<h3>" + T[lang].whatDo + "</h3>";
  s.choices.forEach(function (c, i) {
    html += '<button class="choice" onclick="choose(' + i + ')">' + L(c.label) + "</button>";
  });
  html += "</div>";
  document.getElementById("play").innerHTML = html;
  renderTop();
}

function choose(i) {
  let id = state.cur.id;
  let s = SC[id];
  let c = s.choices[i];
  let fx = {};
  for (let k in c.fx) fx[k] = c.fx[k];
  if (s.scale && fx.shield < 0) fx.shield = Math.round(fx.shield * stormK(state.cur.data));

  let d = DROP[state.world];
  KEYS.forEach(function (k) {
    let drop = d[k] + Math.floor(Math.random() * 3);
    state.meters[k] = Math.min(100, state.meters[k] - drop + (fx[k] || 0));
  });

  state.failKey = null;
  KEYS.forEach(function (k) {
    if (!state.failKey && state.meters[k] <= 0) state.failKey = k;
  });

  if (KEYS.some(function (k) { return state.meters[k] < 30; })) beep();
  state.last = { id: id, choiceIndex: i, fx: fx };
  state.log.push({ day: state.day + 1, id: id, choiceIndex: i });
  renderResult();
}

function renderResult() {
  state.phase = "result";
  let s = SC[state.last.id];
  let c = s.choices[state.last.choiceIndex];
  let fx = state.last.fx;

  let chips = "";
  KEYS.forEach(function (k) {
    if (fx[k]) {
      let up = fx[k] > 0;
      chips += '<span class="chg ' + (up ? "up" : "down") + '">' + ICON[k] + " " + MN[lang][k] + " " + (up ? "+" : "") + fx[k] + "</span>";
    }
  });

  let last = state.day >= ORDER[state.world].length - 1 || state.failKey;
  let btn = last ? T[lang].seeReport : T[lang].nextDay;

  let html = '<div class="sc"><div class="ic">' + s.icon + "</div>";
  html += "<p><b>" + T[lang].youChose + "</b> " + L(c.label) + "</p>";
  html += '<div class="factbox">🧠 <b>' + T[lang].whyWord + "</b> " + L(c.why) + "</div>";
  html += '<div class="center">' + chips + "</div>";
  html += '<p class="note">' + T[lang].dailyNote + "</p>";
  html += '<button class="choice go" onclick="nextDay()">' + btn + "</button></div>";
  document.getElementById("play").innerHTML = html;
  renderTop();
}

function nextDay() {
  if (state.failKey || state.day >= ORDER[state.world].length - 1) {
    state.phase = "end";
    showScreen("endScreen");
    renderEnd();
    return;
  }
  state.day++;
  state.cur = null;
  renderDay();
  maybeAlarm();
}

function renderEnd() {
  state.phase = "end";
  let win = !state.failKey;
  let min = 100;
  KEYS.forEach(function (k) { if (state.meters[k] < min) min = state.meters[k]; });
  let n = !win ? 0 : min >= 45 ? 3 : min >= 25 ? 2 : 1;
  let stars = "⭐".repeat(n) + "☆".repeat(3 - n);

  let html = '<div class="sc">';
  html += '<div class="astro">' + avatar(player.gender || "boy") + "</div>";
  html += "<h2>" + (win ? T[lang].winTitle : T[lang].failTitle) + "</h2>";
  html += '<div class="stars">' + stars + "</div>";
  html += '<p class="story center">' + (win
    ? T[lang].winText.replace("{world}", T[lang][state.world])
    : T[lang].failText.replace("{meter}", MN[lang][state.failKey])) + "</p>";

  html += "<h3>📘 " + T[lang].lessons + "</h3>";
  state.log.forEach(function (e) {
    let s = SC[e.id];
    let c = s.choices[e.choiceIndex];
    html += '<div class="lesson"><b>' + T[lang].dayWord + " " + e.day + " · " + s.icon + " " + L(s.title) + "</b><br>" + L(c.why) + "</div>";
  });

  html += '<p class="note">🛰️ ' + T[lang].dataNote + "</p>";
  html += '<button class="choice go" onclick="restart()">' + T[lang].again + "</button>";
  html += '<button class="ghost" onclick="newPlayer()">' + T[lang].newPlayer + "</button></div>";
  document.getElementById("report").innerHTML = html;
}

function restart() { showScreen("worldScreen"); }
function newPlayer() { showScreen("loginScreen"); }

function init() {
  document.querySelector("#g-girl .av").innerHTML = avatar("girl");
  document.querySelector("#g-boy .av").innerHTML = avatar("boy");

  let row = document.getElementById("ageRow");
  for (let a = 7; a <= 12; a++) {
    let b = document.createElement("button");
    b.className = "age";
    b.dataset.age = a;
    b.textContent = a;
    b.onclick = function () { pickAge(a); };
    row.appendChild(b);
  }

  let saved = loadData("ak_player");
  if (saved) {
    try {
      let p = JSON.parse(saved);
      document.getElementById("nickname").value = p.name || "";
      if (p.age) pickAge(p.age);
      if (p.gender) pickGender(p.gender);
    } catch (e) {}
  }

  setLang(loadData("ak_lang") || "en");
}

init();