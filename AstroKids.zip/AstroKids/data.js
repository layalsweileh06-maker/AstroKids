const NASA_DATA = {
  "generated": "2026-11-13",
  "sources": ["NASA DONKI", "NASA NeoWs"],
  "cme": {
    "count": 87, "medianSpeed": 375, "maxSpeed": 1048,
    "from": "2026-10-14", "to": "2026-11-13",
    "fastest": [
      { "date": "2026-10-17", "speed": 1048 },
      { "date": "2026-11-10", "speed": 974 },
      { "date": "2026-10-20", "speed": 920 },
      { "date": "2026-11-05", "speed": 915 },
      { "date": "2026-11-06", "speed": 902 }
    ],
    "recent": [
      { "date": "2026-11-13", "speed": 308 },
      { "date": "2026-11-13", "speed": 525 },
      { "date": "2026-11-13", "speed": 302 },
      { "date": "2026-11-12", "speed": 327 },
      { "date": "2026-11-12", "speed": 247 },
      { "date": "2026-11-11", "speed": 367 },
      { "date": "2026-11-10", "speed": 803 },
      { "date": "2026-11-10", "speed": 346 },
      { "date": "2026-11-10", "speed": 974 },
      { "date": "2026-11-09", "speed": 338 }
    ]
  },
  "storms": [ { "date": "2026-10-31", "kp": 6.0 } ],
  "asteroids": [
    { "name": "2018 NE1", "date": "2026-11-19", "diameterM": 90, "missLunar": 16.6, "hazardous": false },
    { "name": "2019 WT1", "date": "2026-11-18", "diameterM": 19, "missLunar": 19.6, "hazardous": false },
    { "name": "363790 (2005 JE46)", "date": "2026-11-13", "diameterM": 1158, "missLunar": 20.0, "hazardous": true },
    { "name": "2009 WD54", "date": "2026-11-18", "diameterM": 9, "missLunar": 24.5, "hazardous": false },
    { "name": "2019 VL5", "date": "2026-11-13", "diameterM": 29, "missLunar": 24.8, "hazardous": false },
    { "name": "2004 XK14", "date": "2026-11-19", "diameterM": 140, "missLunar": 34.1, "hazardous": false },
    { "name": "2019 XL", "date": "2026-11-17", "diameterM": 21, "missLunar": 39.8, "hazardous": false },
    { "name": "218017 (2001 XV266)", "date": "2026-11-14", "diameterM": 467, "missLunar": 41.5, "hazardous": false },
    { "name": "2018 LQ2", "date": "2026-11-13", "diameterM": 43, "missLunar": 44.9, "hazardous": false },
    { "name": "2019 HW3", "date": "2026-11-15", "diameterM": 43, "missLunar": 47.1, "hazardous": false },
    { "name": "2005 WD", "date": "2026-11-16", "diameterM": 177, "missLunar": 50.7, "hazardous": true },
    { "name": "2018 VS4", "date": "2026-11-19", "diameterM": 27, "missLunar": 51.3, "hazardous": false }
  ],
  "asteroidTotal": 38,
  "asteroidHazardous": 3
};